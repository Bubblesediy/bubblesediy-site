// BubblesEdiy newsroom v2 (Cloudflare Worker, free plan)
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const slugify=s=>String(s).toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"").slice(0,80);
const tag=(x,t)=>(x.match(new RegExp(`<${t}[^>]*>(?:<!\\[CDATA\\[)?([\\s\\S]*?)(?:\\]\\]>)?</${t}>`))||[])[1]?.trim()||"";
const OK_LICENSE=/^(cc0|cc[ -]by(?!-nc)(?!.*nd)|public domain|pd)/i;
const cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Methods":"GET,POST,OPTIONS","Access-Control-Allow-Headers":"content-type"};
const J=(o,s=200)=>new Response(JSON.stringify(o),{status:s,headers:{...cors,"content-type":"application/json"}});
const IST=(d,o)=>new Date(d).toLocaleString("en-IN",{timeZone:"Asia/Kolkata",...o});
const today=()=>IST(Date.now(),{year:"numeric",month:"short",day:"numeric"});
const isoDay=()=>new Date(Date.now()+19800000).toISOString().slice(0,10);
const dayNo=()=>Math.floor((Date.now()+19800000)/864e5);
const UA={"User-Agent":"BubblesEdiyNewsroom/1.0 (bubblesediy@gmail.com)"};
const RULES=`You draft short news briefs for BubblesEdiy from ONE source item. Rules: use ONLY facts in the item; add no names, numbers, quotes, motives or causes that are not given; rephrase in your own words; neutral tone; max 110 words in 2 paragraphs. If the item is a rumor, gossip, allegation about a private life, health, relationships, or lacks confirmed facts, reply exactly SKIP. If it concerns a disaster, weather or public-safety hazard, reply SKIP unless it quotes an official body. Otherwise reply ONLY JSON: {"title":"","excerpt":"one sentence","content":["",""],"image_query":"main public subject for a photo search, or null"}`;
const STOP=new Set("The This That These Those And But For With From Into After Before While However Monday Tuesday Wednesday Thursday Friday Saturday Sunday".split(" "));
function grounded(j,item){const src=(item.title+" "+item.desc).toLowerCase(),out=[j.title,j.excerpt,...(j.content||[])].join(" ");
  const nums=out.match(/\d[\d,.]*/g)||[],names=out.match(/(?<=[a-z,] )[A-Z][a-z]{2,}/g)||[];
  return nums.every(n=>src.includes(n.toLowerCase()))&&names.every(n=>STOP.has(n)||src.includes(n.toLowerCase()))}
async function llm(env,system,user,max=500){try{
  if(env.ANTHROPIC_API_KEY){const r=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"x-api-key":env.ANTHROPIC_API_KEY,"anthropic-version":"2023-06-01","content-type":"application/json"},body:JSON.stringify({model:"claude-sonnet-4-6",max_tokens:max,system,messages:[{role:"user",content:user}]})});return (await r.json()).content?.[0]?.text||""}
  if(env.AI){const r=await env.AI.run("@cf/meta/llama-3.1-8b-instruct",{max_tokens:max,messages:[{role:"system",content:system},{role:"user",content:user}]});return r.response||""}
 }catch{}return ""}
const CATQ={"breaking-news":"newspaper","india":"India street market","tamil-nadu":"Tamil Nadu temple gopuram","chennai":"Chennai Marina Beach","world":"world map globe","technology":"computer circuit board","business":"stock market trading screen","entertainment":"cinema theatre","sports":"sports stadium","science":"laboratory science","lifestyle":"healthy food vegetables","trending":"city skyline","games":"video game controller","anime":"Akihabara Tokyo","music":"concert stage lights","movies":"cinema auditorium","series":"television set","ott":"television living room"};
async function commonsImage(q,seed=0){if(!q)return null;try{
  const u=`https://commons.wikimedia.org/w/api.php?action=query&format=json&origin=*&generator=search&gsrnamespace=6&gsrlimit=20&gsrsearch=${encodeURIComponent(q+" filetype:bitmap")}&prop=imageinfo&iiprop=url|size|extmetadata&iiurlwidth=1200`;
  const j=await (await fetch(u,{headers:UA})).json(),L=[];
  for(const p of Object.values(j.query?.pages||{})){const ii=p.imageinfo?.[0],m=ii?.extmetadata;if(!ii||!m||(ii.width||1200)<900)continue;const lic=m.LicenseShortName?.value||"";if(!OK_LICENSE.test(lic))continue;
    L.push({url:ii.thumburl||ii.url,credit:`${(m.Artist?.value||"Unknown").replace(/<[^>]+>/g,"").trim()} / Wikimedia Commons, ${lic}`,page:ii.descriptionurl})}
  return L.length?L[seed%Math.min(L.length,6)]:null}catch{}return null}
async function withImage(a){if(a.imageCredit)return a;const img=await commonsImage(CATQ[slugify(a.category)],dayNo()+a.title.length);if(img){a.image=img.url;a.imageCredit=img.credit;a.imageSource=img.page}return a}
const mk=o=>{const now=new Date().toISOString();return{id:"a"+Date.now()+Math.floor(Math.random()*999),title:o.title,slug:slugify(o.title)+"-"+now.slice(5,13).replace(/\D/g,""),category:o.category,excerpt:o.excerpt,content:o.content,author:"BubblesEdiy News Desk",publishedAt:now,updatedAt:now,
  image:o.image||`/images/${slugify(o.category)}.svg`,imageCredit:o.imageCredit,keywords:o.keywords||[o.category.toLowerCase()],demo:false,kind:o.kind||"update",aiAssisted:!!o.ai,source:o.source,status:"published"}};

// ---------- GitHub: many files, ONE commit (one site rebuild) ----------
async function gh(env,path,method="GET",body){const r=await fetch(`https://api.github.com/repos/${env.GITHUB_REPO}/${path}`,{method,headers:{Authorization:`Bearer ${env.GITHUB_TOKEN}`,"User-Agent":"bubblesediy-newsroom",Accept:"application/vnd.github+json"},body:body&&JSON.stringify(body)});
  if(!r.ok)throw new Error(`GitHub ${path} ${r.status}`);return r.json()}
async function commitMany(env,arts,msg){if(!arts.length)return 0;const br=env.GITHUB_BRANCH||"main";
  const ref=await gh(env,`git/ref/heads/${br}`),c=await gh(env,`git/commits/${ref.object.sha}`);
  const tree=await gh(env,"git/trees","POST",{base_tree:c.tree.sha,tree:arts.map(a=>({path:`content/articles/${a.slug}.json`,mode:"100644",type:"blob",content:JSON.stringify(a,null,1)}))});
  const nc=await gh(env,"git/commits","POST",{message:msg,tree:tree.sha,parents:[ref.object.sha]});
  await gh(env,`git/refs/heads/${br}`,"PATCH",{sha:nc.sha});return arts.length}

// ---------- Lane 1: BREAKING (hourly, text only, rolling 20, no git, no rebuild) ----------
async function breaking(env){
  const feeds=(env.BREAKING_FEEDS||"BBC World|https://feeds.bbci.co.uk/news/world/rss.xml,BBC India|https://feeds.bbci.co.uk/news/world/asia/india/rss.xml").split(",").map(x=>x.split("|"));
  let list=JSON.parse(await env.DRAFTS.get("breaking")||"[]"),made=0;
  for(const [name,url] of feeds){let xml="";try{xml=await (await fetch(url)).text()}catch{continue}
    for(const it of xml.split("<item>").slice(1,4)){if(made>=3)break;
      const item={link:tag(it,"link"),title:tag(it,"title"),desc:tag(it,"description").replace(/<[^>]+>/g,"")};
      if(!item.link||list.some(x=>x.url===item.link))continue;
      let t=(await llm(env,"Rewrite the news item as ONE plain sentence under 30 words in your own words. Use ONLY facts given; add no names or numbers not in the text. If unclear or it is rumor/gossip, reply exactly SKIP. Reply with the sentence only.",`Title: ${item.title}\nSummary: ${item.desc}`,80)).trim().replace(/^["']|["']$/g,"");
      if(!t||t.startsWith("SKIP")||t.length>260||!grounded({title:t,excerpt:"",content:[]},item))continue;
      list.unshift({id:Date.now()+"-"+made,text:t,url:item.link,source:name,t:Date.now()});made++}}
  list=list.slice(0,20); // newest first; the 21st (oldest) drops off
  await env.DRAFTS.put("breaking",JSON.stringify(list));return made}

// ---------- Lane 2: entertainment lanes (every 5h, structured free APIs, no AI, auto-publish) ----------
async function anime(){const now=Math.floor(Date.now()/1000);
  const q=`query{Page(perPage:12){airingSchedules(airingAt_greater:${now},airingAt_lesser:${now+43200},sort:TIME){episode airingAt media{title{english romaji}}}}}`;
  const j=await (await fetch("https://graphql.anilist.co",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({query:q})})).json();
  const L=j.data?.Page?.airingSchedules||[];if(!L.length)return[];
  return[mk({title:`Anime episodes airing in the next 12 hours (${today()})`,category:"Anime",excerpt:`${L.length} anime episodes are scheduled to air soon. Times are in Indian Standard Time.`,
    content:[...L.map(x=>`${x.media.title.english||x.media.title.romaji}: episode ${x.episode} airs on ${IST(x.airingAt*1000,{day:"numeric",month:"short",hour:"numeric",minute:"2-digit"})} IST.`),"Air times come from AniList and can change. Where you can watch varies by country."],source:{name:"AniList",url:"https://anilist.co"}})]}
async function tvmaze(){const d=isoDay(),get=async p=>{const r=await fetch("https://api.tvmaze.com"+p,{headers:UA});return r.ok?r.json():[]};
  const pick=(a,re)=>a.map(e=>({e,s:e.show||e._embedded?.show})).filter(x=>x.s&&x.s.weight>=80&&(!re||re.test(x.s.webChannel?.name||""))).sort((a,b)=>b.s.weight-a.s.weight).slice(0,8);
  const line=({e,s})=>`${s.name}${e.name?` ("${e.name}")`:""}: season ${e.season}, episode ${e.number}, on ${s.network?.name||s.webChannel?.name||"TV"}${e.airtime?` at ${e.airtime}`:""}.`;
  const src={name:"TVMaze (CC BY-SA)",url:"https://www.tvmaze.com"},cav="Times are in the broadcaster's local time and can change.",out=[];
  const tv=pick(await get(`/schedule?country=US&date=${d}`));
  if(tv.length)out.push(mk({title:`TV series episodes airing today (${today()})`,category:"Series",excerpt:`${tv.length} popular TV episodes air today.`,content:[...tv.map(line),cav],source:src}));
  const ott=pick(await get(`/schedule/web?date=${d}`),/Netflix|Prime|Disney|Apple|Max|HBO|Hulu|Hotstar|Sony|ZEE|Paramount|Peacock/i);
  if(ott.length)out.push(mk({title:`New streaming episodes on Netflix and other OTT platforms (${today()})`,category:"OTT",excerpt:`${ott.length} popular streaming episodes are released today.`,content:[...ott.map(line),cav],source:src}));
  return out}
async function music(){const j=await (await fetch("https://rss.applemarketingtools.com/api/v2/in/music/most-played/10/songs.json")).json();const L=j.feed?.results||[];if(!L.length)return[];
  return[mk({title:`Most-played songs in India today (${today()})`,category:"Music",excerpt:"The ten most-played songs on Apple Music in India today.",content:[...L.map((x,i)=>`${i+1}. ${x.name} by ${x.artistName}.`),"Chart data from Apple Music."],source:{name:"Apple Music charts",url:"https://music.apple.com/in"}})]}
async function movies(){const q=`SELECT ?fLabel ?d WHERE{?f wdt:P31 wd:Q11424;wdt:P577 ?d.FILTER(?d>=NOW()-"P1D"^^xsd:duration&&?d<=NOW()+"P7D"^^xsd:duration)?f wikibase:sitelinks ?s.FILTER(?s>10)SERVICE wikibase:label{bd:serviceParam wikibase:language "en".}}ORDER BY ?d LIMIT 8`;
  const j=await (await fetch("https://query.wikidata.org/sparql?format=json&query="+encodeURIComponent(q),{headers:UA})).json();
  const L=(j.results?.bindings||[]).filter(b=>!/^Q\d+$/.test(b.fLabel.value));if(!L.length)return[];
  return[mk({title:`Movies releasing this week (${today()})`,category:"Movies",excerpt:`${L.length} notable films have release dates this week.`,content:[...L.map(b=>`${b.fLabel.value}: ${b.d.value.slice(0,10)}.`),"Release dates differ by country and can change. Data from Wikidata (CC0)."],source:{name:"Wikidata (CC0)",url:"https://www.wikidata.org"}})]}
async function games(){const r=await fetch("https://www.gamerpower.com/api/giveaways?type=game&sort-by=popularity",{headers:UA});if(!r.ok)return[];const L=(await r.json()).slice?.(0,6)||[];if(!L.length)return[];
  return[mk({title:`Free games available right now (${today()})`,category:"Games",excerpt:`${L.length} games are currently free to claim for a limited time.`,content:[...L.map(g=>`${g.title} (${g.platforms}): normally ${g.worth}, free ${g.end_date&&g.end_date!=="N/A"?"until "+String(g.end_date).slice(0,10):"for a limited time"}.`),"Offers can end without notice. Check the store page before claiming."],source:{name:"GamerPower",url:"https://www.gamerpower.com"}})]}
async function lanes(env){const fns={anime,tvmaze,music,movies,games},names=Object.keys(fns);
  const res=await Promise.allSettled(names.map(n=>fns[n]()));const arts=res.flatMap(r=>r.status==="fulfilled"?r.value:[]);
  const log=names.map((n,i)=>n+": "+(res[i].status==="fulfilled"?res[i].value.length+" article(s)":"FAILED "+res[i].reason));
  await env.DRAFTS.put("log:lanes",JSON.stringify(log));
  for(const a of arts)await withImage(a);
  if(arts.length)await commitMany(env,arts,"Auto update: entertainment lanes");return{published:arts.length,log}}

// ---------- Lane 3: daily article (Wikipedia birthday of historical person OR healthy-habit tip) ----------
const TIPS=[["Walk a little every day","Regular walking is one of the simplest ways to move more. Health authorities such as the WHO suggest adults aim for at least 150 minutes of moderate physical activity each week, and even short walks after meals add up.","Start with a distance that feels easy and increase it slowly. Stop if you feel pain."],
["Build meals around protein and fibre","Meals that include protein (such as dal, eggs, fish, paneer or beans) and fibre (vegetables, fruit, whole grains) tend to keep you fuller for longer.","Try adding vegetables or pulses to each main meal instead of cutting whole food groups out."],
["Swap sugary drinks for water","Sugary drinks add energy without making you feel full. Replacing some with water, plain buttermilk or unsweetened tea is a simple change.","Carry a bottle with you and keep sweet drinks for occasional treats."],
["Protect your sleep","Poor sleep is linked with higher appetite and lower energy. Most adults do best with roughly seven to nine hours.","Keep regular sleep and wake times and dim screens before bed."],
["Add some strength training","Exercises such as squats, push-ups and resistance bands help maintain muscle, which supports a healthy metabolism as you age.","Two sessions a week is a common starting point. Learn the movements slowly and consider a qualified trainer."],
["Eat slowly and notice fullness","Fullness signals take time to reach the brain. Eating slowly and without a screen can help you notice when you have had enough.","Serve a reasonable portion first and pause before deciding on more."],
["Choose less ultra-processed food","Packaged snacks and fast food are often high in sugar, salt and fat. Choosing more home-cooked meals and whole foods is a lasting habit.","Swap one packaged snack a day for fruit, nuts or roasted chickpeas."]];
async function daily(env){const n=dayNo();let a;
  if(n%2===0){const d=new Date(Date.now()+19800000),mm=String(d.getUTCMonth()+1).padStart(2,"0"),dd=String(d.getUTCDate()).padStart(2,"0");
    const j=await (await fetch(`https://en.wikipedia.org/api/rest_v1/feed/onthisday/births/${mm}/${dd}`,{headers:UA})).json();
    const E=(j.births||[]).filter(b=>b.year<=1940&&b.pages?.[0]?.extract?.length>150); // historical people only
    if(E.length){const b=E[n%E.length],p=b.pages[0],name=p.titles?.normalized||p.title,img=await commonsImage(name);
      a=mk({title:`Born on this day: ${name}`,category:"Trending",kind:"explainer",excerpt:p.extract.split(". ")[0].slice(0,180)+".",content:[`${b.text} (born in ${b.year}).`,p.extract,"Text adapted from Wikipedia, available under the CC BY-SA 4.0 licence."],
        image:img?.url,imageCredit:img?.credit,source:{name:"Wikipedia (CC BY-SA 4.0)",url:p.content_urls?.desktop?.page||"https://en.wikipedia.org"},keywords:["history","born on this day"]})}}
  if(!a){const t=TIPS[n%TIPS.length];a=mk({title:`Healthy habit of the day: ${t[0]}`,category:"Lifestyle",kind:"explainer",ai:true,excerpt:t[1].slice(0,160),content:[t[1],t[2],"This is general information, not medical advice. Speak to a doctor or dietitian before changing your diet or exercise, especially if you have a health condition."],keywords:["health","habits"]})}
  await withImage(a);return await commitMany(env,[a],"Auto update: daily article")}

// ---------- Lane 4: balanced categories (every 6h, drafts; auto-publish after 12h unreviewed) ----------
async function collect(env){
  const feeds=(env.NEWS_FEEDS||"").split(",").map(x=>x.split("|")),max=+(env.MAX_PER_RUN||3);let made=0;
  for(const [name,cat,url] of feeds){if(!url)continue;let xml="";try{xml=await (await fetch(url)).text()}catch{continue}
    for(const it of xml.split("<item>").slice(1)){if(made>=max)return made;
      const item={link:tag(it,"link"),title:tag(it,"title"),desc:tag(it,"description").replace(/<[^>]+>/g,"")};
      if(!item.link||await env.DRAFTS.get("seen:"+item.link))continue;
      await env.DRAFTS.put("seen:"+item.link,"1",{expirationTtl:2592000});
      const t=await llm(env,RULES,`Title: ${item.title}\nSummary: ${item.desc}`,700);if(!t||t.trim().startsWith("SKIP")||!t.includes("{"))continue;
      let j;try{j=JSON.parse(t.slice(t.indexOf("{"),t.lastIndexOf("}")+1))}catch{continue}
      if(!j.title||!j.excerpt||!Array.isArray(j.content)||!grounded(j,item))continue;
      const img=await commonsImage(j.image_query),a=mk({title:j.title,category:cat,kind:"news",ai:true,excerpt:j.excerpt,content:j.content,image:img?.url,imageCredit:img?.credit,source:{name,url:item.link}});
      await env.DRAFTS.put("draft:"+a.slug,JSON.stringify({a,imgPage:img?.page,t:Date.now()}),{expirationTtl:1209600});made++}}
  return made}
async function publishExpired(env){const l=await env.DRAFTS.list({prefix:"draft:",limit:20}),arts=[],del=[];
  for(const k of l.keys){const v=JSON.parse(await env.DRAFTS.get(k.name)||"null");if(v&&v.t&&Date.now()-v.t>12*36e5){arts.push(v.a);del.push(k.name)}}
  if(arts.length){await commitMany(env,arts,"Auto-publish drafts unreviewed after 12 hours");for(const k of del)await env.DRAFTS.delete(k)}return arts.length}

// ---------- Public forms (CORS) ----------
async function limited(env,req,kind){const ip=req.headers.get("CF-Connecting-IP")||"x",k=`rl:${kind}:${ip}:${new Date().toISOString().slice(0,13)}`,n=+(await env.DRAFTS.get(k)||0);
  if(n>=5)return true;await env.DRAFTS.put(k,String(n+1),{expirationTtl:3700});return false}
const EMAIL=/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
async function api(req,env,u){
  if(u.pathname==="/api/breaking")return J(JSON.parse(await env.DRAFTS.get("breaking")||"[]"));
  if(req.method!=="POST")return J({ok:false,error:"Method not allowed"},405);
  let b;try{b=await req.json()}catch{return J({ok:false,error:"Invalid request"},400)}
  if(b.website)return J({ok:true}); // honeypot: bots fill this
  if(u.pathname==="/api/contact"){const name=String(b.name||"").trim(),email=String(b.email||"").trim(),message=String(b.message||"").trim();
    if(!name||name.length>100)return J({ok:false,error:"Please enter your name."},400);
    if(!EMAIL.test(email)||email.length>200)return J({ok:false,error:"Please enter a valid email address."},400);
    if(message.length<10||message.length>3000)return J({ok:false,error:"Message must be 10 to 3000 characters."},400);
    if(await limited(env,req,"c"))return J({ok:false,error:"Too many messages. Please try again later."},429);
    await env.DRAFTS.put("msg:"+Date.now(),JSON.stringify({name,email,message,t:new Date().toISOString()}),{expirationTtl:15552000});
    if(env.WEB3FORMS_KEY){try{await fetch("https://api.web3forms.com/submit",{method:"POST",headers:{"content-type":"application/json",Accept:"application/json"},body:JSON.stringify({access_key:env.WEB3FORMS_KEY,subject:"BubblesEdiy contact form",from_name:"BubblesEdiy website",name,email,message})})}catch{}}
    return J({ok:true})}
  if(u.pathname==="/api/subscribe"){const email=String(b.email||"").trim().toLowerCase();
    if(!EMAIL.test(email)||email.length>200)return J({ok:false,error:"Please enter a valid email address."},400);
    if(!b.consent)return J({ok:false,error:"Please tick the consent box."},400);
    if(await limited(env,req,"s"))return J({ok:false,error:"Too many attempts. Please try again later."},429);
    if(!(await env.DRAFTS.get("sub:"+email)))await env.DRAFTS.put("sub:"+email,JSON.stringify({email,t:new Date().toISOString()}));
    return J({ok:true})}
  return J({ok:false,error:"Not found"},404)}

// ---------- Admin ----------
const authed=(req,env)=>{const h=req.headers.get("Authorization")||"";if(!h.startsWith("Basic "))return false;const p=atob(h.slice(6)).split(":").slice(1).join(":");return !!env.ADMIN_TOKEN&&p===env.ADMIN_TOKEN};
const page=b=>new Response(`<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>Newsroom</title><body style="font:16px system-ui;max-width:760px;margin:auto;padding:16px">${b}`,{headers:{"content-type":"text/html;charset=utf-8"}});
const LANES={breaking,lanes,daily,drafts:collect,expire:publishExpired};
export default{
  async scheduled(ev,env,ctx){const c=ev.cron;
    const run=c==="0 * * * *"?breaking:c==="0 */5 * * *"?lanes:c==="30 0 * * *"?daily:async e=>{await collect(e);return publishExpired(e)};
    ctx.waitUntil(run(env).catch(e=>env.DRAFTS.put("log:error",String(e)+" @"+c)))},
  async fetch(req,env){const u=new URL(req.url);
    if(req.method==="OPTIONS")return new Response(null,{headers:cors});
    if(u.pathname.startsWith("/api/"))return api(req,env,u);
    if(!authed(req,env))return new Response("Login required",{status:401,headers:{"WWW-Authenticate":'Basic realm="Newsroom"'}});
    if(req.method==="POST"&&u.pathname==="/run"){const f=await req.formData(),lane=String(f.get("lane")||"drafts");let r;try{r=await LANES[lane](env)}catch(e){r="ERROR: "+e.message}
      return page(`<p>Lane <b>${esc(lane)}</b> result:</p><pre style="white-space:pre-wrap">${esc(JSON.stringify(r,null,1))}</pre><a href=/>Back</a>`)}
    if(u.pathname==="/messages"){const l=await env.DRAFTS.list({prefix:"msg:",limit:100});let h="<h1>Contact messages</h1><a href=/>Back</a>";
      for(const k of l.keys.reverse()){const m=JSON.parse(await env.DRAFTS.get(k.name)||"{}");h+=`<div style="border:1px solid #ccc;padding:10px;margin:10px 0"><b>${esc(m.name)}</b> &lt;${esc(m.email)}&gt; · ${esc(m.t)}<p style="white-space:pre-wrap">${esc(m.message)}</p></div>`}return page(h)}
    if(u.pathname==="/subscribers"||u.pathname==="/subscribers.csv"){const l=await env.DRAFTS.list({prefix:"sub:",limit:1000}),em=l.keys.map(k=>k.name.slice(4));
      if(u.pathname.endsWith(".csv"))return new Response("email\n"+em.join("\n"),{headers:{"content-type":"text/csv","content-disposition":"attachment; filename=subscribers.csv"}});
      return page(`<h1>Subscribers (${em.length})</h1><a href=/>Back</a> · <a href=/subscribers.csv>Download CSV</a><pre>${esc(em.join("\n"))}</pre>`)}
    if(req.method==="GET"&&u.pathname==="/digest"){
      const feeds=(env.NEWS_FEEDS||"").split(",").map(x=>x.split("|"));let items=[];
      for(const [name,cat,url] of feeds){try{const xml=await (await fetch(url)).text();for(const it of xml.split("<item>").slice(1,5))items.push({name,cat,link:tag(it,"link"),title:tag(it,"title"),desc:tag(it,"description").replace(/<[^>]+>/g,"")})}catch{}}
      const list=items.slice(0,12).map((x,i)=>`${i+1}. [${x.cat}] ${x.title}\nSummary: ${x.desc}\nSource name: ${x.name}\nSource URL: ${x.link}`).join("\n\n");
      const prompt=`You are the morning editor for BubblesEdiy. From the items below choose the 3 most important and write one short news brief for each.\nRules: use ONLY facts stated in the item; add no names, numbers, quotes or causes that are not given; rephrase in your own words; neutral tone; 2 short paragraphs, max 110 words each; skip rumors, gossip, private-life or health claims, and hazard reports not from an official body.\nCategories allowed: Breaking News, India, Tamil Nadu, Chennai, World, Technology, Business, Entertainment, Sports, Science, Lifestyle, Trending.\nReply with ONLY a JSON array like [{"title":"","excerpt":"one sentence","content":["para1","para2"],"category":"World","source_name":"","source_url":"","image_query":"main public subject for a photo search, or null"}]\n\nITEMS:\n\n${list}`;
      return page(`<h1>Morning digest</h1><p><a href=/>Back</a> · <a href=/import>Import Claude's reply</a></p><p>Copy the box, paste into Claude, copy the JSON reply, then Import.</p><textarea rows=20 style="width:100%" readonly onclick="this.select()">${esc(prompt)}</textarea>`)}
    if(u.pathname==="/import"&&req.method==="GET")return page(`<h1>Import articles from Claude</h1><a href=/>Back</a><form method=post action=/import><textarea name=json rows=16 style="width:100%" placeholder="Paste Claude's JSON reply here"></textarea><p><button>Add to review queue</button></p></form>`);
    if(u.pathname==="/import"&&req.method==="POST"){const f=await req.formData();let arr;try{arr=JSON.parse(String(f.get("json")||"").replace(/```json|```/g,"").trim())}catch{return page("That is not valid JSON. Copy Claude's whole reply again. <a href=/import>Back</a>")}
      if(!Array.isArray(arr))arr=[arr];let n=0;
      for(const j of arr.slice(0,5)){if(!j.title||!j.excerpt||!Array.isArray(j.content)||!/^https?:\/\//.test(j.source_url||""))continue;
        const img=await commonsImage(j.image_query),a=mk({title:j.title,category:j.category||"World",kind:"news",ai:true,excerpt:j.excerpt,content:j.content,image:img?.url,imageCredit:img?.credit,source:{name:j.source_name||"Source",url:j.source_url}});
        await env.DRAFTS.put("draft:"+a.slug,JSON.stringify({a,imgPage:img?.page,t:Date.now()}),{expirationTtl:1209600});n++}
      return page(`Added ${n} draft(s). <a href=/>Review them</a>`)}
    if(req.method==="POST"){const f=await req.formData(),slug=String(f.get("slug")),raw=await env.DRAFTS.get("draft:"+slug);if(!raw)return page("Draft not found. <a href=/>Back</a>");
      if(u.pathname==="/approve"){if(f.get("verified")!=="on")return page("Tick the verification box. <a href=/>Back</a>");const {a}=JSON.parse(raw);a.title=String(f.get("title"));a.content=String(f.get("content")).split(/\n\n+/);
        try{await commitMany(env,[a],"Publish: "+a.title)}catch(e){return page("GitHub commit failed ("+esc(e.message)+"). Check GITHUB_TOKEN and GITHUB_REPO. <a href=/>Back</a>")}}
      await env.DRAFTS.delete("draft:"+slug);return Response.redirect(u.origin+"/",303)}
    const list=await env.DRAFTS.list({prefix:"draft:"});const lg=await env.DRAFTS.get("log:lanes"),er=await env.DRAFTS.get("log:error");
    let h=`<h1>Newsroom</h1><p><a href=/digest>Morning digest for Claude</a> · <a href=/import>Import</a> · <a href=/messages>Messages</a> · <a href=/subscribers>Subscribers</a></p>
<form method=post action=/run>Run a lane now: <select name=lane><option value=breaking>Breaking (text only)</option><option value=lanes>Entertainment lanes</option><option value=daily>Daily article</option><option value=drafts>Balanced drafts</option><option value=expire>Publish 12h-old drafts</option></select> <button>Run</button></form>
${er?`<p style="color:#b00">Last error: ${esc(er)}</p>`:""}<h2>Review queue (${list.keys.length}); drafts unreviewed after 12 hours publish automatically</h2>`;
    for(const k of list.keys){const {a,imgPage,t}=JSON.parse(await env.DRAFTS.get(k.name));
      h+=`<form method=post action=/approve style="border:1px solid #ccc;padding:12px;margin:16px 0"><input type=hidden name=slug value="${esc(a.slug)}"><p><b>${esc(a.category)}</b> · queued ${esc(IST(t||Date.now(),{day:"numeric",month:"short",hour:"numeric",minute:"2-digit"}))} IST · <a href="${esc(a.source.url)}" target=_blank rel=noopener>${esc(a.source.name)}</a></p>
${a.imageCredit?`<img src="${esc(a.image)}" style="max-width:100%"><p><small>Image: ${esc(a.imageCredit)} · <a href="${esc(imgPage)}" target=_blank rel=noopener>license page</a></small></p>`:"<p><small>Generic illustration will be used.</small></p>"}
<input name=title value="${esc(a.title)}" style="width:100%;font-size:18px"><textarea name=content rows=8 style="width:100%">${esc(a.content.join("\n\n"))}</textarea>
<p><label><input type=checkbox name=verified> I checked the facts and the image license.</label></p><button>Approve and publish</button> <button formaction=/reject>Reject</button></form>`}
    return page(h+(lg?`<h3>Last entertainment run</h3><pre>${esc(JSON.parse(lg).join("\n"))}</pre>`:""))}};
